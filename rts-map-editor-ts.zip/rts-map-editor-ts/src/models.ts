import * as THREE from 'three';
import { GLTFLoader, type GLTF } from 'three/addons/loaders/GLTFLoader.js';
import type { ModelDef, AttachedLight } from './types';
import { DEFAULT_TOON_GRADIENT } from './gradientMap';

const gltfLoader = new GLTFLoader();

/** Wrap a plain color in a toon material so built-ins band the same way. */
function toonMat(color: number): THREE.MeshToonMaterial {
  return new THREE.MeshToonMaterial({ color, gradientMap: DEFAULT_TOON_GRADIENT });
}

/**
 * Built-in primitive model definitions. The Lantern and Tower include a
 * default light template — the user can still toggle "attach light" off
 * before placing, or enable it on instances that didn't get one.
 */
function defaultModelDefs(): ModelDef[] {
  return [
    {
      name: 'Tree', source: 'builtin', build: () => {
        const g = new THREE.Group();
        const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.2, 1, 8), toonMat(0x712B13));
        trunk.position.y = 0.5; g.add(trunk);
        const leaves = new THREE.Mesh(new THREE.ConeGeometry(0.7, 1.4, 8), toonMat(0x3B6D11));
        leaves.position.y = 1.5; g.add(leaves);
        return g;
      },
    },
    {
      name: 'Rock', source: 'builtin', build: () =>
        new THREE.Mesh(new THREE.DodecahedronGeometry(0.5), toonMat(0x888780)),
    },
    {
      name: 'House', source: 'builtin', build: () => {
        const g = new THREE.Group();
        const base = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1, 1.2), toonMat(0xD3D1C7));
        base.position.y = 0.5; g.add(base);
        const roof = new THREE.Mesh(new THREE.ConeGeometry(0.95, 0.6, 4), toonMat(0x993C1D));
        roof.position.y = 1.3; roof.rotation.y = Math.PI / 4; g.add(roof);
        return g;
      },
      defaultLight: { color: 0xffaa55, intensity: 4, range: 6, offset: [0, 1.1, 0] },
    },
    {
      name: 'Tower', source: 'builtin', build: () => {
        const g = new THREE.Group();
        const body = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.6, 2.2, 8), toonMat(0x5F5E5A));
        body.position.y = 1.1; g.add(body);
        const top = new THREE.Mesh(new THREE.ConeGeometry(0.65, 0.7, 8), toonMat(0x501313));
        top.position.y = 2.55; g.add(top);
        return g;
      },
      defaultLight: { color: 0xff7733, intensity: 6, range: 8, offset: [0, 2.5, 0] },
    },
    {
      name: 'Lantern', source: 'builtin', build: () => {
        const g = new THREE.Group();
        const post = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 1.6, 6), toonMat(0x222222));
        post.position.y = 0.8; g.add(post);
        const head = new THREE.Mesh(
          new THREE.BoxGeometry(0.25, 0.25, 0.25),
          // emissive to show even when unlit; toon doesn't shade emissive
          new THREE.MeshToonMaterial({
            color: 0xffcc66, emissive: 0xffaa33, gradientMap: DEFAULT_TOON_GRADIENT,
          }),
        );
        head.position.y = 1.6; g.add(head);
        return g;
      },
      defaultLight: { color: 0xffcc66, intensity: 5, range: 5, offset: [0, 1.6, 0] },
    },
  ];
}

export function loadGLBFromArrayBuffer(buf: ArrayBuffer, name: string): Promise<ModelDef> {
  return new Promise((resolve, reject) => {
    gltfLoader.parse(
      buf,
      '',
      (gltf: GLTF) => {
        const proto = gltf.scene;
        resolve({
          name,
          source: 'glb',
          glbData: buf,
          build: (): THREE.Object3D => {
            const c = proto.clone(true);
            c.traverse(o => {
              const mesh = o as THREE.Mesh;
              if (mesh.isMesh) {
                const mat = mesh.material;
                mesh.material = Array.isArray(mat)
                  ? mat.map(m => m.clone())
                  : (mat as THREE.Material).clone();
              }
            });
            return c;
          },
        });
      },
      err => reject(err),
    );
  });
}

/**
 * Attach a configured PointLight to a placed model, plus a tiny emissive
 * sphere "gizmo" so the user can see where the light is even when the
 * scene is bright. The light is added as a child so it inherits transforms.
 */
export function attachLight(obj: THREE.Object3D, cfg: AttachedLight): THREE.PointLight {
  // Remove existing light/gizmo if re-attaching
  detachLight(obj);
  const light = new THREE.PointLight(cfg.color, cfg.intensity, cfg.range, 2);
  light.position.set(cfg.offset[0], cfg.offset[1], cfg.offset[2]);
  light.userData['kind'] = 'attached-light';
  obj.add(light);
  const gizmo = new THREE.Mesh(
    new THREE.SphereGeometry(0.08, 8, 6),
    new THREE.MeshBasicMaterial({ color: cfg.color }),
  );
  gizmo.position.copy(light.position);
  gizmo.userData['kind'] = 'attached-light-gizmo';
  obj.add(gizmo);
  obj.userData['attachedLight'] = cfg;
  return light;
}

export function detachLight(obj: THREE.Object3D): void {
  const toRemove: THREE.Object3D[] = [];
  obj.traverse(child => {
    const k = child.userData['kind'];
    if (k === 'attached-light' || k === 'attached-light-gizmo') toRemove.push(child);
  });
  for (const c of toRemove) c.parent?.remove(c);
  delete obj.userData['attachedLight'];
}

/** Owns the list of model definitions, placed instances, and place/remove ops. */
export class ModelLibrary {
  scene: THREE.Scene;
  defs: ModelDef[] = defaultModelDefs();
  placed: Set<THREE.Object3D> = new Set();
  currentDefIndex = 0;
  onChange: () => void = () => {};

  constructor(scene: THREE.Scene) {
    this.scene = scene;
  }

  setCurrent(idx: number): void {
    this.currentDefIndex = idx;
    this.onChange();
  }

  async addGLBFiles(files: FileList | File[]): Promise<number> {
    const list = Array.from(files);
    const results = await Promise.allSettled(
      list.map(async (f): Promise<ModelDef> => {
        const buf = await f.arrayBuffer();
        const name = f.name.replace(/\.(glb|gltf)$/i, '');
        return loadGLBFromArrayBuffer(buf, name);
      }),
    );
    let loaded = 0;
    for (const r of results) {
      if (r.status === 'fulfilled') {
        this.defs.push(r.value);
        loaded++;
      } else {
        console.error(r.reason);
      }
    }
    this.onChange();
    return loaded;
  }

  /**
   * Build a placed instance (NOT yet added to scene) at a world point. The
   * caller (a command) decides when to actually add it. If withLight is set
   * and the def has a defaultLight, attach it.
   */
  build(
    defIndex: number,
    worldPoint: THREE.Vector3,
    yOffset: number,
    scale: number,
    withLight: boolean,
  ): THREE.Object3D | null {
    const def = this.defs[defIndex];
    if (!def) return null;
    const m = def.build();
    m.position.set(worldPoint.x, worldPoint.y + yOffset, worldPoint.z);
    m.scale.setScalar(scale);
    m.userData['kind'] = 'model';
    m.userData['defIndex'] = defIndex;
    if (withLight && def.defaultLight) attachLight(m, def.defaultLight);
    return m;
  }

  /** Walk up from a raycast hit to the placed root, or null if not a placed model. */
  findPlacedRoot(hitObject: THREE.Object3D): THREE.Object3D | null {
    let top: THREE.Object3D | null = hitObject;
    while (top && top.parent && !this.placed.has(top)) top = top.parent;
    return top && this.placed.has(top) ? top : null;
  }

  clearPlaced(): void {
    this.placed.forEach(m => this.scene.remove(m));
    this.placed.clear();
  }

  stripGLBs(): void {
    for (let i = this.defs.length - 1; i >= 0; i--) {
      if (this.defs[i].source === 'glb') this.defs.splice(i, 1);
    }
    this.onChange();
  }
}
