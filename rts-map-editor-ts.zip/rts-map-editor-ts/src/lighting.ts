import * as THREE from 'three';

export type Mood = 'day' | 'dusk' | 'night';

export interface MoodPreset {
  background: number;
  sunColor: number;
  sunIntensity: number;
  ambientColor: number;
  ambientIntensity: number;
}

/**
 * Mood presets shift the scene-wide color temperature. The point-light
 * pools from buildings read most strongly against the night background;
 * day is mostly for inspecting geometry.
 */
export const MOODS: Record<Mood, MoodPreset> = {
  day: {
    background: 0xf1efe8,
    sunColor: 0xffffff,
    sunIntensity: 1.0,
    ambientColor: 0xffffff,
    ambientIntensity: 0.45,
  },
  dusk: {
    background: 0x3a2d4a,
    sunColor: 0xff9a5a,
    sunIntensity: 0.75,
    ambientColor: 0x5a4878,
    ambientIntensity: 0.35,
  },
  night: {
    background: 0x0d1a3a,
    sunColor: 0x6a82d8,
    sunIntensity: 0.5,
    ambientColor: 0x1a2548,
    ambientIntensity: 0.5,
  },
};

/**
 * Holds the directional sun and ambient. Exposed so the editor can swap
 * mood without rebuilding the scene.
 */
export class Lighting {
  scene: THREE.Scene;
  sun: THREE.DirectionalLight;
  ambient: THREE.AmbientLight;
  mood: Mood = 'night';

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.sun = new THREE.DirectionalLight(0xffffff, 1.0);
    this.sun.position.set(20, 30, 15);
    this.ambient = new THREE.AmbientLight(0xffffff, 0.45);
    scene.add(this.sun);
    scene.add(this.ambient);
    this.applyMood('night');
  }

  applyMood(mood: Mood): void {
    this.mood = mood;
    const p = MOODS[mood];
    this.scene.background = new THREE.Color(p.background);
    this.sun.color.setHex(p.sunColor);
    this.sun.intensity = p.sunIntensity;
    this.ambient.color.setHex(p.ambientColor);
    this.ambient.intensity = p.ambientIntensity;
  }
}
