# RTS Map Editor

Browser-based map editor for an RTS-style game. Built with Three.js, TypeScript,
and Vite.

## Setup

```bash
npm install
npm run dev      # http://localhost:5173 with hot reload
npm run build    # type-check + production bundle into dist/
npm run preview  # serve the built bundle
```

## File layout

```
index.html              Vite entry. Loads /src/main.ts.
vite.config.ts          Dev server + build config.
tsconfig.json           Strict TS config (DOM lib, bundler resolution).
package.json
src/
  main.ts               App entry. Wires every module together and runs the loop.
  styles.css            All visual styling (imported by main.ts).
  scene.ts              Renderer, scene, perspective camera, OrbitControls, lights.
  textures.ts           Procedural ground textures (Grass/Sand/Rock/Snow/Dirt).
  terrain.ts            Terrain mesh: heights, vertex colors, void-Y triangle culling.
  water.ts              Transparent water plane that follows the map dimensions.
  selection.ts          Vertex selection set, screen-space box pick, height ops.
  models.ts             Built-in model defs + GLB upload + place/remove logic.
  io.ts                 Save/load JSON (with embedded base64 GLB payloads).
  ui.ts                 DOM helpers: panel population, tool buttons, toasts.
  dom.ts                Typed element-lookup helpers (byId, inputById).
  types.ts              Shared interfaces (SaveData, ModelDef, TextureDef, ToolName).
```

## Features

- Configurable map width, length, and vertex density. **Rebuild** regenerates the grid.
- Four tools: **Select** (box-select; shift to add), **Orbit** (camera), **Place** and **Remove** for models.
- Height editing on the current selection: nudges (±1, ±0.1), exact "Set to" value, "Flatten to average".
- Texture painting: five built-in swatches; click to paint the current selection.
- Models: four built-in primitives plus **Upload GLB** to add any glTF binary. Y-offset and scale at placement time.
- Water plane with adjustable Y and visibility toggle.
- Void threshold: triangles whose every vertex sits at or below this Y are dropped from the mesh.
- **Save JSON** writes a self-contained file with map dimensions, heights, vertex paint, water/void settings, and base64-embedded GLB definitions. **Load JSON** restores everything.

## Replacing the procedural textures

`src/textures.ts` exports `TEX_DEFS` as `TextureDef[]` (`{name, dataUrl, color}`). To
use real images, swap each entry for `{name, dataUrl: '/path/to/img.png', color:
new THREE.Color(<dominant hex>)}`. The vertex-color path in `terrain.ts` uses
the `color` field; to render an actual tiled image on the surface, switch the
terrain material to a textured one and pass per-vertex UV indices into a
texture atlas.

## Save format compatibility note

Saves reference models by their index in `MODEL_DEFS` (built-ins first, then
GLBs in upload order) and textures by their index in `TEX_DEFS`. Don't reorder
either list if you want old saves to load correctly. For long-term storage,
swap the index references for stable string IDs in `io.ts`.
