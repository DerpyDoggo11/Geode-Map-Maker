# RTS Map Editor

Browser-based map editor for an RTS-style game. Built with Three.js, TypeScript,
and Vite. Uses cel-shaded (toon) materials with attachable building lights for a
stylized look.

## Setup

```bash
npm install
npm run dev      # http://localhost:5173 with hot reload
npm run build    # type-check + production bundle into dist/
npm run preview  # serve the built bundle
```

## File layout

```
index.html              Vite entry. Loads /src/main.ts.
vite.config.ts          Dev server + build config.
tsconfig.json           Strict TS config (DOM lib, bundler resolution).
package.json
src/
  main.ts               App entry. Wires every module together and runs the loop.
  styles.css            All visual styling (imported by main.ts).
  scene.ts              Renderer, scene, perspective camera, OrbitControls.
  lighting.ts           Day/dusk/night moods. Owns sun + ambient.
  gradientMap.ts        Toon gradient ramp (3 brightness bands).
  textures.ts           Procedural ground textures (Grass/Sand/Rock/Snow/Dirt).
  terrain.ts            Terrain mesh (MeshToonMaterial), heights, void culling.
  water.ts              Toon-shaded water plane.
  selection.ts          Vertex selection, screen-space box pick, height computations.
  models.ts             Built-in toon models + GLB upload + attached PointLights.
  history.ts            Generic undo/redo manager (Command pattern, bounded stack).
  commands.ts           Concrete commands (HeightEdit, Paint, PlaceModel, RemoveModel).
  io.ts                 Save/load JSON (v3 schema, with v2 migration).
  ui.ts                 DOM helpers: panel population, tool buttons, toasts.
  dom.ts                Typed element-lookup helpers.
  types.ts              Shared interfaces (SaveData, ModelDef, AttachedLight, ToolName).
```

## Visual style

The cel-shaded look comes from `MeshToonMaterial` plus a 1×3 gradient texture
(see `gradientMap.ts`). Each material's lit/unlit Lambert term is sampled
against this ramp, producing hard bands instead of a smooth gradient. Switch to
"Night" mood and place a building with a light to see the classic warm-pool-on-
dark-ground look from the reference image.

Tweak `DEFAULT_TOON_GRADIENT` for different band placement — `[0.3, 0.55, 1.0]`
gives darker shadows, `[0.4, 0.7, 1.0]` gives a softer look. Add more stops for
more bands. Set `magFilter` to `LinearFilter` to soften the band edges.

## Building lights

Each model can have an attached `PointLight`. Built-in House, Tower, and
Lantern come with sensible defaults. To light a placed model, check "Attach
light when placing" before clicking. Adjust color, intensity, range, and Y
offset in the panel.

A small glowing sphere "gizmo" sits at the light position so you can find it
when the scene is bright. Lights are children of their model, so they move and
rotate with it. They persist in saved JSON.

If you want more than the toon-material-with-PointLights approach can give you
— hard warm/cool tinting per light, palette quantization — read the discussion
in `gradientMap.ts` and consider replacing `MeshToonMaterial` with a custom
`ShaderMaterial`. The structure is already set up so swapping the terrain
material is a one-line change.

## Undo / redo

- **Buttons** in the panel's History section, or
- **⌘/Ctrl+Z** for undo, **⌘/Ctrl+Shift+Z** or **Ctrl+Y** for redo
- Bounded at 200 entries. Selection changes are NOT undoable (annoying);
  state changes are: height edits, paint, place model, remove model.
- Map rebuild and JSON load both clear history, since they invalidate
  vertex identity.

The history system uses the Command pattern (`history.ts` + `commands.ts`). To
add a new undoable operation, implement `Command` with `do()` and `undo()` and
call `history.execute(cmd)` instead of doing the change directly.

## Save format

Version 3 schema. Includes map dimensions, heights, vertex paint, water/void,
mood, attached light configs per model, and base64-embedded GLB definitions.
V2 saves (no lights, no mood) still load — they default to day mood with no
attached lights.

Saves reference models by their index in `MODEL_DEFS` and textures by their
index in `TEX_DEFS`. Don't reorder either list if you want old saves to load
correctly. For long-term storage, swap the index references for stable string
IDs in `io.ts`.
